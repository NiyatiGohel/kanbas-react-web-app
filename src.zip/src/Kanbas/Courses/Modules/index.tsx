import Modules from "./modules";

export default function mod() {
  return (
    <div id="wd-home" className="d-flex">
  <div className="flex-fill me-5">
          <Modules />
          </div>
  
</div>

  );
}
